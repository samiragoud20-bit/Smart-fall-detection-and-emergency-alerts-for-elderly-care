#define BLYNK_TEMPLATE_ID "TMPL39Bk3rj3h"
#define BLYNK_TEMPLATE_NAME "Fall detuction"
#define BLYNK_AUTH_TOKEN "SvZSaM7R50E_QUgUFpFdw3Dp6Osh4s5B"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <Wire.h>
#include <MPU6050_tockn.h>

char ssid[] = "Samira";
char pass[] = "pandu_gadu";

MPU6050 mpu6050(Wire);

// WiFi Status LED (Onboard)
#define WIFI_LED 2

// LEDs
#define GREEN_LED1 18
#define GREEN_LED2 19
#define RED_LED1   25
#define RED_LED2   26

// Buttons
#define CANCEL_BTN 32
#define SOS_BTN    33

// Buzzer
#define BUZZER     27

bool fallDetected = false;
bool emergencySent = false;
unsigned long fallStartTime = 0;

//---------------------------------------
void wifiStatusIndicator() {

  static unsigned long previousMillis = 0;
  static bool ledState = false;

  if (WiFi.status() == WL_CONNECTED && Blynk.connected()) {

    digitalWrite(WIFI_LED, HIGH);
  }
  else {

    if (millis() - previousMillis >= 500) {

      previousMillis = millis();
      ledState = !ledState;

      digitalWrite(WIFI_LED, ledState);
    }
  }
}
//---------------------------------------

void setup() {

  Serial.begin(115200);

  Wire.begin(21, 22);

  pinMode(WIFI_LED, OUTPUT);

  pinMode(GREEN_LED1, OUTPUT);
  pinMode(GREEN_LED2, OUTPUT);
  pinMode(RED_LED1, OUTPUT);
  pinMode(RED_LED2, OUTPUT);

  pinMode(BUZZER, OUTPUT);

  pinMode(CANCEL_BTN, INPUT_PULLUP);
  pinMode(SOS_BTN, INPUT_PULLUP);

  digitalWrite(GREEN_LED1, HIGH);
  digitalWrite(GREEN_LED2, HIGH);

  digitalWrite(RED_LED1, LOW);
  digitalWrite(RED_LED2, LOW);

  Serial.println("Initializing MPU6050...");

  mpu6050.begin();

  Serial.println("Keep MPU6050 still...");
  delay(1000);

  mpu6050.calcGyroOffsets(true);

  Serial.println("Connecting WiFi...");

  WiFi.begin(ssid, pass);

  while (WiFi.status() != WL_CONNECTED) {

    digitalWrite(WIFI_LED, HIGH);
    delay(200);
    digitalWrite(WIFI_LED, LOW);
    delay(200);

    Serial.print(".");
  }

  Serial.println("\nWiFi Connected");

  Blynk.config(BLYNK_AUTH_TOKEN);

  while (!Blynk.connect()) {

    digitalWrite(WIFI_LED, HIGH);
    delay(200);
    digitalWrite(WIFI_LED, LOW);
    delay(200);

    Serial.print("*");
  }

  digitalWrite(WIFI_LED, HIGH);

  Serial.println("\nBlynk Connected");

  Serial.println("================================");
  Serial.println("SMART FALL DETECTION SYSTEM");
  Serial.println("SYSTEM READY");
  Serial.println("================================");
}

void loop() {

  Blynk.run();
  wifiStatusIndicator();

  mpu6050.update();

  float angleX = abs(mpu6050.getAngleX());
  float angleY = abs(mpu6050.getAngleY());

  float accX = mpu6050.getAccX();
  float accY = mpu6050.getAccY();
  float accZ = mpu6050.getAccZ();

  float totalAcc = sqrt(
    accX * accX +
    accY * accY +
    accZ * accZ
  );

  // SOS BUTTON
  if (digitalRead(SOS_BTN) == LOW) {

    Serial.println("SOS ALERT ACTIVATED");

    digitalWrite(RED_LED2, HIGH);

    Blynk.logEvent(
      "sos_alert",
      "SOS Button Pressed! Immediate assistance required."
    );

    for (int i = 0; i < 10; i++) {

      digitalWrite(BUZZER, HIGH);
      delay(150);

      digitalWrite(BUZZER, LOW);
      delay(150);
    }

    digitalWrite(RED_LED2, LOW);

    while (digitalRead(SOS_BTN) == LOW);
    delay(300);
  }

  // FALL DETECTION
  if ((totalAcc > 2.0) &&
      (angleX > 60 || angleY > 60) &&
      !fallDetected &&
      !emergencySent) {

    fallDetected = true;
    fallStartTime = millis();

    digitalWrite(RED_LED1, HIGH);
    digitalWrite(BUZZER, HIGH);

    Serial.println("================================");
    Serial.println("FALL DETECTED");
    Serial.println("Press CANCEL within 10 seconds");
    Serial.println("================================");
  }

  // CANCEL BUTTON
  if (fallDetected && digitalRead(CANCEL_BTN) == LOW) {

    fallDetected = false;
    emergencySent = false;

    digitalWrite(BUZZER, LOW);

    digitalWrite(RED_LED1, LOW);
    digitalWrite(RED_LED2, LOW);

    Serial.println("================================");
    Serial.println("ALERT RESET SUCCESSFULLY");
    Serial.println("SYSTEM MONITORING...");
    Serial.println("================================");

    while (digitalRead(CANCEL_BTN) == LOW);
    delay(300);
  }

  // SEND ALERT AFTER 10 SECONDS
  if (fallDetected &&
      (millis() - fallStartTime >= 10000)) {

    fallDetected = false;
    emergencySent = true;

    digitalWrite(BUZZER, LOW);

    digitalWrite(RED_LED1, LOW);
    digitalWrite(RED_LED2, HIGH);

    Serial.println("================================");
    Serial.println("EMERGENCY ALERT SENT");
    Serial.println("================================");

    Blynk.logEvent(
      "fall_alert",
      "Fall Detected! Emergency assistance required."
    );

    for (int i = 0; i < 20; i++) {

      digitalWrite(BUZZER, HIGH);
      delay(100);

      digitalWrite(BUZZER, LOW);
      delay(100);
    }
  }

  // AUTO RESET AFTER ALERT
  if (emergencySent) {

    delay(5000);

    emergencySent = false;

    digitalWrite(RED_LED2, LOW);
    digitalWrite(BUZZER, LOW);

    Serial.println("================================");
    Serial.println("SYSTEM RESET");
    Serial.println("MONITORING...");
    Serial.println("================================");
  }

  delay(50);
}